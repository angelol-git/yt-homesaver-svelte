import{l as o,a as r}from"../chunks/r-31ZrmR.js";export{o as load_css,r as start};
